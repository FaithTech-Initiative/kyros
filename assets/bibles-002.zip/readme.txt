Bible SuperSearch Bible Export

JSON
JavaScript Object Notation


These Bibles are legally shareable and reshareable for non-commercial purposes.  Please share them with others.

Please see the copyright statement on each Bible for more information.

These files are provided as-is and without warranty.


Index of Bibles Included: 

File                                        Bible
================================================================================================================================================================


EN-English
--------------------------------------------------------------------------------------------------------------------------------------------
* asvs.json ------------------------------- American Standard Version w Strong's
* bishops.json ---------------------------- Bishops Bible (1568)
* coverdale.json -------------------------- Coverdale Bible (1535)
* geneva.json ----------------------------- Geneva Bible (1587)
* kjv_strongs.json ------------------------ KJV with Strongs (1611 / 1769)
* tyndale.json ---------------------------- Tyndale Bible (1534)
* web.json -------------------------------- World English Bible (2006)


