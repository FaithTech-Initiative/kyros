Bible SuperSearch Bible Export

JSON
JavaScript Object Notation


These Bibles are legally shareable and reshareable for non-commercial purposes.  Please share them with others.

Please see the copyright statement on each Bible for more information.

These files are provided as-is and without warranty.


Index of Bibles Included: 

File                                        Bible
================================================================================================================================================================


EN-English
--------------------------------------------------------------------------------------------------------------------------------------------
* asv.json -------------------------------- American Standard Version (1901)
* kjv.json -------------------------------- Authorized King James Version (1611 / 1769)
* net.json -------------------------------- NET Bible® (1996-2016)
* web.json -------------------------------- World English Bible (2006)


